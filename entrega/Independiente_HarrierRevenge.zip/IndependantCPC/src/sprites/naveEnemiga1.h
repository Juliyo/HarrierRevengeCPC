// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_NAVEENEMIGA1_H_
#define _RESOURCES_NAVEENEMIGA1_H_

#include <types.h>
#define G_NAVEENEMIGA1_0_W 4
#define G_NAVEENEMIGA1_0_H 8
extern const u8 g_naveEnemiga1_0[4 * 8];
#define G_NAVEENEMIGA1_1_W 4
#define G_NAVEENEMIGA1_1_H 8
extern const u8 g_naveEnemiga1_1[4 * 8];
#define G_NAVEENEMIGA1_2_W 4
#define G_NAVEENEMIGA1_2_H 8
extern const u8 g_naveEnemiga1_2[4 * 8];
#define G_NAVEENEMIGA1_3_W 4
#define G_NAVEENEMIGA1_3_H 8
extern const u8 g_naveEnemiga1_3[4 * 8];

#endif
