// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_FLORES1_H_
#define _RESOURCES_FLORES1_H_

#include <types.h>
#define G_FLORES1_0_W 40
#define G_FLORES1_0_H 10
extern const u8 g_flores1_0[40 * 10];
#define G_FLORES1_1_W 40
#define G_FLORES1_1_H 10
extern const u8 g_flores1_1[40 * 10];

#endif
