// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_EXPLOSION_H_
#define _RESOURCES_EXPLOSION_H_

#include <types.h>
#define G_EXPLOSION_00_W 4
#define G_EXPLOSION_00_H 8
extern const u8 g_explosion_00[4 * 8];
#define G_EXPLOSION_01_W 4
#define G_EXPLOSION_01_H 8
extern const u8 g_explosion_01[4 * 8];
#define G_EXPLOSION_02_W 4
#define G_EXPLOSION_02_H 8
extern const u8 g_explosion_02[4 * 8];
#define G_EXPLOSION_03_W 4
#define G_EXPLOSION_03_H 8
extern const u8 g_explosion_03[4 * 8];
#define G_EXPLOSION_04_W 4
#define G_EXPLOSION_04_H 8
extern const u8 g_explosion_04[4 * 8];
#define G_EXPLOSION_05_W 4
#define G_EXPLOSION_05_H 8
extern const u8 g_explosion_05[4 * 8];
#define G_EXPLOSION_06_W 4
#define G_EXPLOSION_06_H 8
extern const u8 g_explosion_06[4 * 8];
#define G_EXPLOSION_07_W 4
#define G_EXPLOSION_07_H 8
extern const u8 g_explosion_07[4 * 8];
#define G_EXPLOSION_08_W 4
#define G_EXPLOSION_08_H 8
extern const u8 g_explosion_08[4 * 8];
#define G_EXPLOSION_09_W 4
#define G_EXPLOSION_09_H 8
extern const u8 g_explosion_09[4 * 8];
#define G_EXPLOSION_10_W 4
#define G_EXPLOSION_10_H 8
extern const u8 g_explosion_10[4 * 8];
#define G_EXPLOSION_11_W 4
#define G_EXPLOSION_11_H 8
extern const u8 g_explosion_11[4 * 8];

#endif
