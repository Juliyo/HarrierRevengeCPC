Alfonso José Rodríguez Gómez
Antonio Rebollo Berná
Alfonso José Rodríguez Gómez

Harrier Revenge

CPCTelera

If you want to compile this project you don't have to do anything special, you have to make in the parent folder of the project and run into emulator, for instance, WinAPE.