// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_CAPTUTADA_H_
#define _RESOURCES_CAPTUTADA_H_

#include <types.h>
#define G_CAPTUTADA_W 4
#define G_CAPTUTADA_H 12
extern const u8 g_captutada[4 * 12];

#endif
