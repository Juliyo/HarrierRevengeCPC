// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_PALETAJULINHO_H_
#define _RESOURCES_PALETAJULINHO_H_

#include <types.h>
extern u8* const g_tileset[72];

#define G_PALETAJULINHO_00_W 2
#define G_PALETAJULINHO_00_H 4
extern const u8 g_paletajulinho_00[2 * 4];
#define G_PALETAJULINHO_01_W 2
#define G_PALETAJULINHO_01_H 4
extern const u8 g_paletajulinho_01[2 * 4];
#define G_PALETAJULINHO_02_W 2
#define G_PALETAJULINHO_02_H 4
extern const u8 g_paletajulinho_02[2 * 4];
#define G_PALETAJULINHO_03_W 2
#define G_PALETAJULINHO_03_H 4
extern const u8 g_paletajulinho_03[2 * 4];
#define G_PALETAJULINHO_04_W 2
#define G_PALETAJULINHO_04_H 4
extern const u8 g_paletajulinho_04[2 * 4];
#define G_PALETAJULINHO_05_W 2
#define G_PALETAJULINHO_05_H 4
extern const u8 g_paletajulinho_05[2 * 4];
#define G_PALETAJULINHO_06_W 2
#define G_PALETAJULINHO_06_H 4
extern const u8 g_paletajulinho_06[2 * 4];
#define G_PALETAJULINHO_07_W 2
#define G_PALETAJULINHO_07_H 4
extern const u8 g_paletajulinho_07[2 * 4];
#define G_PALETAJULINHO_08_W 2
#define G_PALETAJULINHO_08_H 4
extern const u8 g_paletajulinho_08[2 * 4];
#define G_PALETAJULINHO_09_W 2
#define G_PALETAJULINHO_09_H 4
extern const u8 g_paletajulinho_09[2 * 4];
#define G_PALETAJULINHO_10_W 2
#define G_PALETAJULINHO_10_H 4
extern const u8 g_paletajulinho_10[2 * 4];
#define G_PALETAJULINHO_11_W 2
#define G_PALETAJULINHO_11_H 4
extern const u8 g_paletajulinho_11[2 * 4];
#define G_PALETAJULINHO_12_W 2
#define G_PALETAJULINHO_12_H 4
extern const u8 g_paletajulinho_12[2 * 4];
#define G_PALETAJULINHO_13_W 2
#define G_PALETAJULINHO_13_H 4
extern const u8 g_paletajulinho_13[2 * 4];
#define G_PALETAJULINHO_14_W 2
#define G_PALETAJULINHO_14_H 4
extern const u8 g_paletajulinho_14[2 * 4];
#define G_PALETAJULINHO_15_W 2
#define G_PALETAJULINHO_15_H 4
extern const u8 g_paletajulinho_15[2 * 4];
#define G_PALETAJULINHO_16_W 2
#define G_PALETAJULINHO_16_H 4
extern const u8 g_paletajulinho_16[2 * 4];
#define G_PALETAJULINHO_17_W 2
#define G_PALETAJULINHO_17_H 4
extern const u8 g_paletajulinho_17[2 * 4];
#define G_PALETAJULINHO_18_W 2
#define G_PALETAJULINHO_18_H 4
extern const u8 g_paletajulinho_18[2 * 4];
#define G_PALETAJULINHO_19_W 2
#define G_PALETAJULINHO_19_H 4
extern const u8 g_paletajulinho_19[2 * 4];
#define G_PALETAJULINHO_20_W 2
#define G_PALETAJULINHO_20_H 4
extern const u8 g_paletajulinho_20[2 * 4];
#define G_PALETAJULINHO_21_W 2
#define G_PALETAJULINHO_21_H 4
extern const u8 g_paletajulinho_21[2 * 4];
#define G_PALETAJULINHO_22_W 2
#define G_PALETAJULINHO_22_H 4
extern const u8 g_paletajulinho_22[2 * 4];
#define G_PALETAJULINHO_23_W 2
#define G_PALETAJULINHO_23_H 4
extern const u8 g_paletajulinho_23[2 * 4];
#define G_PALETAJULINHO_24_W 2
#define G_PALETAJULINHO_24_H 4
extern const u8 g_paletajulinho_24[2 * 4];
#define G_PALETAJULINHO_25_W 2
#define G_PALETAJULINHO_25_H 4
extern const u8 g_paletajulinho_25[2 * 4];
#define G_PALETAJULINHO_26_W 2
#define G_PALETAJULINHO_26_H 4
extern const u8 g_paletajulinho_26[2 * 4];
#define G_PALETAJULINHO_27_W 2
#define G_PALETAJULINHO_27_H 4
extern const u8 g_paletajulinho_27[2 * 4];
#define G_PALETAJULINHO_28_W 2
#define G_PALETAJULINHO_28_H 4
extern const u8 g_paletajulinho_28[2 * 4];
#define G_PALETAJULINHO_29_W 2
#define G_PALETAJULINHO_29_H 4
extern const u8 g_paletajulinho_29[2 * 4];
#define G_PALETAJULINHO_30_W 2
#define G_PALETAJULINHO_30_H 4
extern const u8 g_paletajulinho_30[2 * 4];
#define G_PALETAJULINHO_31_W 2
#define G_PALETAJULINHO_31_H 4
extern const u8 g_paletajulinho_31[2 * 4];
#define G_PALETAJULINHO_32_W 2
#define G_PALETAJULINHO_32_H 4
extern const u8 g_paletajulinho_32[2 * 4];
#define G_PALETAJULINHO_33_W 2
#define G_PALETAJULINHO_33_H 4
extern const u8 g_paletajulinho_33[2 * 4];
#define G_PALETAJULINHO_34_W 2
#define G_PALETAJULINHO_34_H 4
extern const u8 g_paletajulinho_34[2 * 4];
#define G_PALETAJULINHO_35_W 2
#define G_PALETAJULINHO_35_H 4
extern const u8 g_paletajulinho_35[2 * 4];
#define G_PALETAJULINHO_36_W 2
#define G_PALETAJULINHO_36_H 4
extern const u8 g_paletajulinho_36[2 * 4];
#define G_PALETAJULINHO_37_W 2
#define G_PALETAJULINHO_37_H 4
extern const u8 g_paletajulinho_37[2 * 4];
#define G_PALETAJULINHO_38_W 2
#define G_PALETAJULINHO_38_H 4
extern const u8 g_paletajulinho_38[2 * 4];
#define G_PALETAJULINHO_39_W 2
#define G_PALETAJULINHO_39_H 4
extern const u8 g_paletajulinho_39[2 * 4];
#define G_PALETAJULINHO_40_W 2
#define G_PALETAJULINHO_40_H 4
extern const u8 g_paletajulinho_40[2 * 4];
#define G_PALETAJULINHO_41_W 2
#define G_PALETAJULINHO_41_H 4
extern const u8 g_paletajulinho_41[2 * 4];
#define G_PALETAJULINHO_42_W 2
#define G_PALETAJULINHO_42_H 4
extern const u8 g_paletajulinho_42[2 * 4];
#define G_PALETAJULINHO_43_W 2
#define G_PALETAJULINHO_43_H 4
extern const u8 g_paletajulinho_43[2 * 4];
#define G_PALETAJULINHO_44_W 2
#define G_PALETAJULINHO_44_H 4
extern const u8 g_paletajulinho_44[2 * 4];
#define G_PALETAJULINHO_45_W 2
#define G_PALETAJULINHO_45_H 4
extern const u8 g_paletajulinho_45[2 * 4];
#define G_PALETAJULINHO_46_W 2
#define G_PALETAJULINHO_46_H 4
extern const u8 g_paletajulinho_46[2 * 4];
#define G_PALETAJULINHO_47_W 2
#define G_PALETAJULINHO_47_H 4
extern const u8 g_paletajulinho_47[2 * 4];
#define G_PALETAJULINHO_48_W 2
#define G_PALETAJULINHO_48_H 4
extern const u8 g_paletajulinho_48[2 * 4];
#define G_PALETAJULINHO_49_W 2
#define G_PALETAJULINHO_49_H 4
extern const u8 g_paletajulinho_49[2 * 4];
#define G_PALETAJULINHO_50_W 2
#define G_PALETAJULINHO_50_H 4
extern const u8 g_paletajulinho_50[2 * 4];
#define G_PALETAJULINHO_51_W 2
#define G_PALETAJULINHO_51_H 4
extern const u8 g_paletajulinho_51[2 * 4];
#define G_PALETAJULINHO_52_W 2
#define G_PALETAJULINHO_52_H 4
extern const u8 g_paletajulinho_52[2 * 4];
#define G_PALETAJULINHO_53_W 2
#define G_PALETAJULINHO_53_H 4
extern const u8 g_paletajulinho_53[2 * 4];
#define G_PALETAJULINHO_54_W 2
#define G_PALETAJULINHO_54_H 4
extern const u8 g_paletajulinho_54[2 * 4];
#define G_PALETAJULINHO_55_W 2
#define G_PALETAJULINHO_55_H 4
extern const u8 g_paletajulinho_55[2 * 4];
#define G_PALETAJULINHO_56_W 2
#define G_PALETAJULINHO_56_H 4
extern const u8 g_paletajulinho_56[2 * 4];
#define G_PALETAJULINHO_57_W 2
#define G_PALETAJULINHO_57_H 4
extern const u8 g_paletajulinho_57[2 * 4];
#define G_PALETAJULINHO_58_W 2
#define G_PALETAJULINHO_58_H 4
extern const u8 g_paletajulinho_58[2 * 4];
#define G_PALETAJULINHO_59_W 2
#define G_PALETAJULINHO_59_H 4
extern const u8 g_paletajulinho_59[2 * 4];
#define G_PALETAJULINHO_60_W 2
#define G_PALETAJULINHO_60_H 4
extern const u8 g_paletajulinho_60[2 * 4];
#define G_PALETAJULINHO_61_W 2
#define G_PALETAJULINHO_61_H 4
extern const u8 g_paletajulinho_61[2 * 4];
#define G_PALETAJULINHO_62_W 2
#define G_PALETAJULINHO_62_H 4
extern const u8 g_paletajulinho_62[2 * 4];
#define G_PALETAJULINHO_63_W 2
#define G_PALETAJULINHO_63_H 4
extern const u8 g_paletajulinho_63[2 * 4];
#define G_PALETAJULINHO_64_W 2
#define G_PALETAJULINHO_64_H 4
extern const u8 g_paletajulinho_64[2 * 4];
#define G_PALETAJULINHO_65_W 2
#define G_PALETAJULINHO_65_H 4
extern const u8 g_paletajulinho_65[2 * 4];
#define G_PALETAJULINHO_66_W 2
#define G_PALETAJULINHO_66_H 4
extern const u8 g_paletajulinho_66[2 * 4];
#define G_PALETAJULINHO_67_W 2
#define G_PALETAJULINHO_67_H 4
extern const u8 g_paletajulinho_67[2 * 4];
#define G_PALETAJULINHO_68_W 2
#define G_PALETAJULINHO_68_H 4
extern const u8 g_paletajulinho_68[2 * 4];
#define G_PALETAJULINHO_69_W 2
#define G_PALETAJULINHO_69_H 4
extern const u8 g_paletajulinho_69[2 * 4];
#define G_PALETAJULINHO_70_W 2
#define G_PALETAJULINHO_70_H 4
extern const u8 g_paletajulinho_70[2 * 4];
#define G_PALETAJULINHO_71_W 2
#define G_PALETAJULINHO_71_H 4
extern const u8 g_paletajulinho_71[2 * 4];

#endif
