//
// File resources/map31.tmx converted to csv using cpct_tmx2csv [20161025 18:03:20 DST]
//   * Width:  40 columns (40 bytes, 8 bits per column)
//   * Height: 40 rows
//   * Bytes:  1600 bytes (40 x 40)
//
#include <types.h>

// Generated CSV tilemap from resources/map31.tmx
//   1600 bytes (40 x 40)
//   40*40 items (8 bits per item)
//
#define g_map31_W  40
#define g_map31_H  40
extern const u8 g_map31[40*40];
