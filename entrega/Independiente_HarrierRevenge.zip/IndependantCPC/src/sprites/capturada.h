// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_CAPTURADA_H_
#define _RESOURCES_CAPTURADA_H_

#include <types.h>
#define G_CAPTURADA_W 8
#define G_CAPTURADA_H 20
extern const u8 g_capturada[8 * 20];

#endif
