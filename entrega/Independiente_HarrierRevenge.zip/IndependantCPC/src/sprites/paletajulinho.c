#include "paletajulinho.h"
// Data created with Img2CPC - (c) Retroworks - 2007-2015
u8* const g_tileset[72] = { 
	g_paletajulinho_00, g_paletajulinho_01, g_paletajulinho_02, g_paletajulinho_03, g_paletajulinho_04, g_paletajulinho_05, g_paletajulinho_06, g_paletajulinho_07, g_paletajulinho_08, g_paletajulinho_09, g_paletajulinho_10, g_paletajulinho_11, g_paletajulinho_12, g_paletajulinho_13, g_paletajulinho_14, g_paletajulinho_15, g_paletajulinho_16, g_paletajulinho_17, g_paletajulinho_18, g_paletajulinho_19, g_paletajulinho_20, g_paletajulinho_21, g_paletajulinho_22, g_paletajulinho_23, g_paletajulinho_24, g_paletajulinho_25, g_paletajulinho_26, g_paletajulinho_27, g_paletajulinho_28, g_paletajulinho_29, g_paletajulinho_30, g_paletajulinho_31, g_paletajulinho_32, g_paletajulinho_33, g_paletajulinho_34, g_paletajulinho_35, g_paletajulinho_36, g_paletajulinho_37, g_paletajulinho_38, g_paletajulinho_39, g_paletajulinho_40, g_paletajulinho_41, g_paletajulinho_42, g_paletajulinho_43, g_paletajulinho_44, g_paletajulinho_45, g_paletajulinho_46, g_paletajulinho_47, g_paletajulinho_48, g_paletajulinho_49, g_paletajulinho_50, g_paletajulinho_51, g_paletajulinho_52, g_paletajulinho_53, g_paletajulinho_54, g_paletajulinho_55, g_paletajulinho_56, g_paletajulinho_57, g_paletajulinho_58, g_paletajulinho_59, g_paletajulinho_60, g_paletajulinho_61, g_paletajulinho_62, g_paletajulinho_63, g_paletajulinho_64, g_paletajulinho_65, g_paletajulinho_66, g_paletajulinho_67, g_paletajulinho_68, g_paletajulinho_69, g_paletajulinho_70, g_paletajulinho_71
};
// Tile g_paletajulinho_00: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_00[2 * 4] = {
	0x00, 0x00,
	0x00, 0x00,
	0x00, 0x00,
	0x00, 0x00
};

// Tile g_paletajulinho_01: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_01[2 * 4] = {
	0xc0, 0xc0,
	0xc0, 0xc0,
	0xc0, 0xc0,
	0xc0, 0xc0
};

// Tile g_paletajulinho_02: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_02[2 * 4] = {
	0x0c, 0x0c,
	0x0c, 0x0c,
	0x0c, 0x0c,
	0x0c, 0x0c
};

// Tile g_paletajulinho_03: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_03[2 * 4] = {
	0xc0, 0x0c,
	0xc0, 0x0c,
	0xc0, 0xc0,
	0xc0, 0xc0
};

// Tile g_paletajulinho_04: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_04[2 * 4] = {
	0xcc, 0xcc,
	0xcc, 0xcc,
	0xcc, 0xcc,
	0xcc, 0xcc
};

// Tile g_paletajulinho_05: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_05[2 * 4] = {
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_06: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_06[2 * 4] = {
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf0
};

// Tile g_paletajulinho_07: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_07[2 * 4] = {
	0xc0, 0xc0,
	0xc0, 0xc0,
	0x0c, 0xc0,
	0x0c, 0xc0
};

// Tile g_paletajulinho_08: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_08[2 * 4] = {
	0x3c, 0x3c,
	0x3c, 0x3c,
	0x3c, 0x3c,
	0x3c, 0x3c
};

// Tile g_paletajulinho_09: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_09[2 * 4] = {
	0xfc, 0xfc,
	0xfc, 0xfc,
	0xfc, 0xfc,
	0xfc, 0xfc
};

// Tile g_paletajulinho_10: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_10[2 * 4] = {
	0x03, 0x03,
	0x03, 0x03,
	0x03, 0x03,
	0x03, 0x03
};

// Tile g_paletajulinho_11: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_11[2 * 4] = {
	0x30, 0x70,
	0x30, 0x70,
	0x30, 0x70,
	0x30, 0x70
};

// Tile g_paletajulinho_12: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_12[2 * 4] = {
	0xc3, 0xc3,
	0xc3, 0xc3,
	0xc3, 0xc3,
	0xc3, 0xc3
};

// Tile g_paletajulinho_13: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_13[2 * 4] = {
	0x0f, 0x0f,
	0x0f, 0x0f,
	0x0f, 0x0f,
	0x0f, 0x0f
};

// Tile g_paletajulinho_14: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_14[2 * 4] = {
	0xcf, 0xcf,
	0xcf, 0xcf,
	0xcf, 0xcf,
	0xcf, 0xcf
};

// Tile g_paletajulinho_15: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_15[2 * 4] = {
	0xb0, 0x30,
	0xb0, 0x30,
	0xb0, 0x30,
	0xb0, 0x30
};

// Tile g_paletajulinho_16: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_16[2 * 4] = {
	0x33, 0x33,
	0x33, 0x33,
	0x33, 0x33,
	0x33, 0x33
};

// Tile g_paletajulinho_17: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_17[2 * 4] = {
	0xf3, 0xf3,
	0xf3, 0xf3,
	0xf3, 0xf3,
	0xf3, 0xf3
};

// Tile g_paletajulinho_18: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_18[2 * 4] = {
	0x3f, 0x3f,
	0x3f, 0x3f,
	0x3f, 0x3f,
	0x3f, 0x3f
};

// Tile g_paletajulinho_19: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_19[2 * 4] = {
	0xf0, 0xf0,
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_20: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_20[2 * 4] = {
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

// Tile g_paletajulinho_21: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_21[2 * 4] = {
	0xc3, 0xc3,
	0x03, 0x43,
	0x0f, 0x43,
	0x0f, 0x43
};

// Tile g_paletajulinho_22: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_22[2 * 4] = {
	0xc3, 0xc3,
	0x83, 0x03,
	0x83, 0x0f,
	0x83, 0x0f
};

// Tile g_paletajulinho_23: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_23[2 * 4] = {
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30,
	0xf0, 0xf0
};

// Tile g_paletajulinho_24: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_24[2 * 4] = {
	0x0f, 0x43,
	0x0f, 0x43,
	0x03, 0x43,
	0xc3, 0xc3
};

// Tile g_paletajulinho_25: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_25[2 * 4] = {
	0x83, 0x0f,
	0x83, 0x0f,
	0x83, 0x03,
	0xc3, 0xc3
};

// Tile g_paletajulinho_26: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_26[2 * 4] = {
	0x83, 0x0f,
	0x83, 0x0f,
	0x83, 0x0f,
	0x83, 0x0f
};

// Tile g_paletajulinho_27: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_27[2 * 4] = {
	0x30, 0x60,
	0x30, 0x60,
	0x30, 0x60,
	0x30, 0x60
};

// Tile g_paletajulinho_28: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_28[2 * 4] = {
	0x0f, 0x43,
	0x0f, 0x43,
	0x0f, 0x43,
	0x0f, 0x43
};

// Tile g_paletajulinho_29: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_29[2 * 4] = {
	0xc3, 0xc3,
	0x03, 0x03,
	0x0f, 0x0f,
	0x0f, 0x0f
};

// Tile g_paletajulinho_30: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_30[2 * 4] = {
	0x0f, 0x0f,
	0x0f, 0x0f,
	0x03, 0x03,
	0xc3, 0xc3
};

// Tile g_paletajulinho_31: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_31[2 * 4] = {
	0x90, 0x30,
	0x90, 0x30,
	0x90, 0x30,
	0x90, 0x30
};

// Tile g_paletajulinho_32: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_32[2 * 4] = {
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0xff,
	0x30, 0xba
};

// Tile g_paletajulinho_33: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_33[2 * 4] = {
	0x30, 0x30,
	0x30, 0x30,
	0xff, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_34: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_34[2 * 4] = {
	0xf0, 0xf0,
	0xfc, 0xf0,
	0xfc, 0xf0,
	0xf0, 0xf0
};

// Tile g_paletajulinho_35: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_35[2 * 4] = {
	0x30, 0x24,
	0x30, 0x24,
	0x30, 0x24,
	0x30, 0x24
};

// Tile g_paletajulinho_36: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_36[2 * 4] = {
	0x30, 0xba,
	0x30, 0xff,
	0x30, 0xba,
	0x30, 0xba
};

// Tile g_paletajulinho_37: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_37[2 * 4] = {
	0x30, 0x30,
	0xff, 0x30,
	0x30, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_38: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_38[2 * 4] = {
	0xf0, 0xf0,
	0xf4, 0xf8,
	0xf4, 0xf8,
	0xf0, 0xf0
};

// Tile g_paletajulinho_39: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_39[2 * 4] = {
	0x18, 0x30,
	0x18, 0x30,
	0x18, 0x30,
	0x18, 0x30
};

// Tile g_paletajulinho_40: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_40[2 * 4] = {
	0x30, 0xff,
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_41: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_41[2 * 4] = {
	0xff, 0x30,
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30
};

// Tile g_paletajulinho_42: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_42[2 * 4] = {
	0x3c, 0x3c,
	0x39, 0x36,
	0x39, 0x36,
	0x3c, 0x3c
};

// Tile g_paletajulinho_43: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_43[2 * 4] = {
	0x3f, 0x3f,
	0x7f, 0xbf,
	0x7f, 0xbf,
	0x3f, 0x3f
};

// Tile g_paletajulinho_44: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_44[2 * 4] = {
	0x3c, 0x3c,
	0x3c, 0x33,
	0x3c, 0x33,
	0x3c, 0x3c
};

// Tile g_paletajulinho_45: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_45[2 * 4] = {
	0x0c, 0x0c,
	0x1c, 0x2c,
	0x1c, 0x2c,
	0x0c, 0x0c
};

// Tile g_paletajulinho_46: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_46[2 * 4] = {
	0x0c, 0x0c,
	0x0c, 0x0c,
	0x1c, 0x2c,
	0x1c, 0x2c
};

// Tile g_paletajulinho_47: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_47[2 * 4] = {
	0x3f, 0x3f,
	0x3f, 0x3f,
	0xff, 0x3f,
	0xff, 0x3f
};

// Tile g_paletajulinho_48: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_48[2 * 4] = {
	0xfc, 0xfc,
	0xed, 0xde,
	0xed, 0xde,
	0xfc, 0xfc
};

// Tile g_paletajulinho_49: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_49[2 * 4] = {
	0xfc, 0xfc,
	0xfc, 0xfc,
	0xfc, 0xcf,
	0xfc, 0xcf
};

// Tile g_paletajulinho_50: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_50[2 * 4] = {
	0xf3, 0xf3,
	0xb7, 0x7b,
	0xb7, 0x7b,
	0xf3, 0xf3
};

// Tile g_paletajulinho_51: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_51[2 * 4] = {
	0x3f, 0xf3,
	0x3f, 0xf3,
	0xf3, 0xf3,
	0xf3, 0xf3
};

// Tile g_paletajulinho_52: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_52[2 * 4] = {
	0x38, 0x30,
	0x38, 0x30,
	0x38, 0x30,
	0x38, 0x30
};

// Tile g_paletajulinho_53: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_53[2 * 4] = {
	0x30, 0x34,
	0x30, 0x34,
	0x30, 0x34,
	0x30, 0x34
};

// Tile g_paletajulinho_54: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_54[2 * 4] = {
	0x3a, 0x30,
	0x3a, 0x30,
	0x3a, 0x30,
	0x3a, 0x30
};

// Tile g_paletajulinho_55: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_55[2 * 4] = {
	0x30, 0x35,
	0x30, 0x35,
	0x30, 0x35,
	0x30, 0x35
};

// Tile g_paletajulinho_56: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_56[2 * 4] = {
	0x30, 0x30,
	0x30, 0x30,
	0x30, 0x30,
	0x3f, 0x3f
};

// Tile g_paletajulinho_57: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_57[2 * 4] = {
	0x30, 0x71,
	0x30, 0x71,
	0x30, 0x71,
	0x30, 0x71
};

// Tile g_paletajulinho_58: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_58[2 * 4] = {
	0x12, 0x30,
	0x12, 0x30,
	0x12, 0x30,
	0x12, 0x30
};

// Tile g_paletajulinho_59: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_59[2 * 4] = {
	0xcf, 0xcf,
	0xcf, 0xcf,
	0xcf, 0xcf,
	0xcf, 0xcf
};

// Tile g_paletajulinho_60: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_60[2 * 4] = {
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf5,
	0xf0, 0xfa
};

// Tile g_paletajulinho_61: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_61[2 * 4] = {
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xfa, 0xf0,
	0xf5, 0xf0
};

// Tile g_paletajulinho_62: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_62[2 * 4] = {
	0xff, 0xef,
	0x3c, 0xff,
	0x3c, 0xff,
	0x3c, 0xff
};

// Tile g_paletajulinho_63: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_63[2 * 4] = {
	0xcf, 0xcf,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

// Tile g_paletajulinho_64: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_64[2 * 4] = {
	0xf0, 0xfa,
	0xf0, 0xff,
	0xf0, 0xfa,
	0xf0, 0xfa
};

// Tile g_paletajulinho_65: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_65[2 * 4] = {
	0xf5, 0xf0,
	0xff, 0xf0,
	0xf5, 0xf0,
	0xf5, 0xf0
};

// Tile g_paletajulinho_66: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_66[2 * 4] = {
	0x7d, 0xff,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

// Tile g_paletajulinho_67: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_67[2 * 4] = {
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

// Tile g_paletajulinho_68: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_68[2 * 4] = {
	0xf0, 0xfa,
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf0
};

// Tile g_paletajulinho_69: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_69[2 * 4] = {
	0xf5, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf0,
	0xf0, 0xf0
};

// Tile g_paletajulinho_70: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_70[2 * 4] = {
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

// Tile g_paletajulinho_71: 4x4 pixels, 2x4 bytes.
const u8 g_paletajulinho_71[2 * 4] = {
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff,
	0xff, 0xff
};

