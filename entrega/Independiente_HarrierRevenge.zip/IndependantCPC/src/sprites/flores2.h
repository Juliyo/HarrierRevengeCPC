// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_FLORES2_H_
#define _RESOURCES_FLORES2_H_

#include <types.h>
#define G_FLORES2_0_W 40
#define G_FLORES2_0_H 10
extern const u8 g_flores2_0[40 * 10];
#define G_FLORES2_1_W 40
#define G_FLORES2_1_H 10
extern const u8 g_flores2_1[40 * 10];

#endif
