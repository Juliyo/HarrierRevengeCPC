// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_NAVEENEMIGA3_H_
#define _RESOURCES_NAVEENEMIGA3_H_

#include <types.h>
#define G_NAVEENEMIGA3_0_W 4
#define G_NAVEENEMIGA3_0_H 8
extern const u8 g_naveEnemiga3_0[4 * 8];
#define G_NAVEENEMIGA3_1_W 4
#define G_NAVEENEMIGA3_1_H 8
extern const u8 g_naveEnemiga3_1[4 * 8];
#define G_NAVEENEMIGA3_2_W 4
#define G_NAVEENEMIGA3_2_H 8
extern const u8 g_naveEnemiga3_2[4 * 8];
#define G_NAVEENEMIGA3_3_W 4
#define G_NAVEENEMIGA3_3_H 8
extern const u8 g_naveEnemiga3_3[4 * 8];

#endif
