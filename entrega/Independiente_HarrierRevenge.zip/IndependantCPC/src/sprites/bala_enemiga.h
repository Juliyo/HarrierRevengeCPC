// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_BALA_ENEMIGA_H_
#define _RESOURCES_BALA_ENEMIGA_H_

#include <types.h>
#define G_BALA_ENEMIGA_W 2
#define G_BALA_ENEMIGA_H 4
extern const u8 g_bala_enemiga[2 * 4];

#endif
