// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_NAVEENEMIGA2_H_
#define _RESOURCES_NAVEENEMIGA2_H_

#include <types.h>
#define G_NAVEENEMIGA2_0_W 4
#define G_NAVEENEMIGA2_0_H 8
extern const u8 g_naveEnemiga2_0[4 * 8];
#define G_NAVEENEMIGA2_1_W 4
#define G_NAVEENEMIGA2_1_H 8
extern const u8 g_naveEnemiga2_1[4 * 8];
#define G_NAVEENEMIGA2_2_W 4
#define G_NAVEENEMIGA2_2_H 8
extern const u8 g_naveEnemiga2_2[4 * 8];
#define G_NAVEENEMIGA2_3_W 4
#define G_NAVEENEMIGA2_3_H 8
extern const u8 g_naveEnemiga2_3[4 * 8];

#endif
