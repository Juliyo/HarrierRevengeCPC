// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_NAVES_H_
#define _RESOURCES_NAVES_H_

#include <types.h>
extern const u8 g_palette[16];

#define G_NAVES_0_W 6
#define G_NAVES_0_H 12
extern const u8 g_naves_0[6 * 12];
#define G_NAVES_1_W 6
#define G_NAVES_1_H 12
extern const u8 g_naves_1[6 * 12];
#define G_NAVES_2_W 6
#define G_NAVES_2_H 12
extern const u8 g_naves_2[6 * 12];
#define G_NAVES_3_W 6
#define G_NAVES_3_H 12
extern const u8 g_naves_3[6 * 12];

#endif
