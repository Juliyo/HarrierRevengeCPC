#include "bala_enemiga.h"
// Data created with Img2CPC - (c) Retroworks - 2007-2015
// Tile g_bala_enemiga: 4x4 pixels, 2x4 bytes.
const u8 g_bala_enemiga[2 * 4] = {
	0x40, 0x80,
	0x94, 0x68,
	0x94, 0x68,
	0x40, 0x80
};

