// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_HEARTH_H_
#define _RESOURCES_HEARTH_H_

#include <types.h>
#define G_HEARTH_W 9
#define G_HEARTH_H 16
extern const u8 g_hearth[9 * 16];

#endif
