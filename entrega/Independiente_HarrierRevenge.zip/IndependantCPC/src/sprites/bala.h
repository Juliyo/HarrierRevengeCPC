// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _RESOURCES_BALA_H_
#define _RESOURCES_BALA_H_

#include <types.h>
#define G_BALA_0_W 2
#define G_BALA_0_H 4
extern const u8 g_bala_0[2 * 4];
#define G_BALA_1_W 2
#define G_BALA_1_H 4
extern const u8 g_bala_1[2 * 4];
#define G_BALA_2_W 2
#define G_BALA_2_H 4
extern const u8 g_bala_2[2 * 4];
#define G_BALA_3_W 2
#define G_BALA_3_H 4
extern const u8 g_bala_3[2 * 4];

#endif
